TedSubtitle

Description:
     Get ted talk's subtitle from TED.com and convert subtitle of TED video to SRT format(SubRip Subtitle File).

Usage: tedSubtitle URL languageCode output.src 
       or you can modify the testTedSub.bat directly.

Files:
    tedSubtitle.pl   Perl script   
    tedSubtitle.exe  Executable file converted from Perl script
    testTedSub.bat   Batch processing file.

Online Doc: http://blog.csdn.net/thinkhy/article/details/6564434   
Last version of source code: https://gist.github.com/949659 

License: Apache License V2.0

Authors: thinkhy<think.hy@gmail.com>

Bug reports are welcome. Email to the current maintainers may be sent to <think.hy@gmail.com>.
I will be happy if the script could help you. 
----------------------

TedSubtitle is Licensed under the Apache License V2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
       
